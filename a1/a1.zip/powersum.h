#ifndef POWERSUM_H
#define POWERSUM_H
int power_overflow(int b, int n );
int mypow(int b, int n);
int powersum(int b, int n);
#endif