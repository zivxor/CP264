#include <stdio.h>
#include "mymortgage.h"
/**
 * Compute b raised to the power n (b^n) returning a `float`.
 *
 * @param b the base (non-negative float)
 * @param n the exponent (non-negative integer)
 * @return the value b^n as a `float`; returns 0.0f if the result overflows or underflows.
 */
float mypowf(float b, int n){
    if (n < 0 || b < 0.0f) {
        return 0.0f; // Invalid input
    }
    if (n == 0) {
        return 1.0f; // Any number to the power of 0 is 1
    }
    float result = 1.0f;
    for (int i = 0; i < n; i++) {
        result *= b;
        if (result == 0.0f) {
            return 0.0f; // Underflow
        }
    }
    return result;
}

/**
 * Compute the monthly mortgage payment using the standard amortization formula.
 * Use `myfabs` and `mypowf` where appropriate.
 *
 * @param principal_amount the loan principal (float, > 0)
 * @param annual_interest_rate the annual interest rate in percent (float, e.g. 5.0 means 5%)
 * @param years the loan term in years (int, > 0)
 * @return the monthly payment amount as a `float`.
 */
float monthly_payment(float principal_amount, float annual_interest_rate, int years){
    if (principal_amount <= 0.0f || annual_interest_rate < 0.0f || years <= 0) {
        return 0.0f; // Invalid input
    }

    float monthly_interest_rate = (annual_interest_rate / 100.0f) / 12.0f;
    int total_payments = years * 12;

    if (monthly_interest_rate == 0.0f) {
        return principal_amount / total_payments; // No interest case
    }

    float numerator = monthly_interest_rate * mypowf(1.0f + monthly_interest_rate, total_payments);
    float denominator = mypowf(1.0f + monthly_interest_rate, total_payments) - 1.0f;

    if (denominator == 0.0f) {
        return 0.0f; // Avoid division by zero
    }

    return principal_amount * (numerator / denominator);
}

/**
 * Compute the total amount paid over the life of the loan.
 *
 * @param principal_amount the loan principal (float)
 * @param annual_interest_rate the annual interest rate in percent (float)
 * @param years the loan term in years (int)
 * @return the total payment (monthly payment * number of months) as a `float`.
 */
float total_payment(float principal_amount, float annual_interest_rate, int years){
    float monthly_pay = monthly_payment(principal_amount, annual_interest_rate, years);
    int total_months = years * 12;
    return monthly_pay * total_months;
}

/**
 * Compute the total interest paid over the life of the loan.
 *
 * @param principal_amount the loan principal (float)
 * @param annual_interest_rate the annual interest rate in percent (float)
 * @param years the loan term in years (int)
 * @return the total interest paid (total payment - principal) as a `float`.
 */
float total_interest(float principal_amount, float annual_interest_rate, int years){
    float total_pay = total_payment(principal_amount, annual_interest_rate, years);
    return total_pay - principal_amount;
}
